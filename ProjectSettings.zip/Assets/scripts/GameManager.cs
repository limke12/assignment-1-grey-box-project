﻿using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    // 静态实例，但不用 DontDestroyOnLoad
    public static GameManager Instance;

    [Header("UI 组件")]
    public GameObject winPanel;        // 胜利面板
    public Text winText;               // 胜利文字
    public Button restartButton;       // 重新开始按钮
    public Button mainMenuButton;      // 主菜单按钮

    [Header("场景名称")]
    public string mainMenuSceneName = "MainMenu";

    private bool isGameWin = false;

    void Awake()
    {
        // 每个场景有自己的 GameManager，不跨场景保留
        Instance = this;
        // 注意：没有 DontDestroyOnLoad
    }

    void Start()
    {
        // 一开始隐藏胜利面板
        if (winPanel != null)
            winPanel.SetActive(false);

        // 绑定按钮事件
        if (restartButton != null)
            restartButton.onClick.AddListener(RestartGame);
        if (mainMenuButton != null)
            mainMenuButton.onClick.AddListener(ReturnToMainMenu);
    }

    // 胜利时调用
    public void GameWin()
    {
        if (isGameWin) return;
        isGameWin = true;

        // 显示胜利面板
        if (winPanel != null)
        {
            winPanel.SetActive(true);
            if (winText != null)
                winText.text = "You Win! 🎉";
        }

        // 停止小球移动
        StopPlayer();
    }

    // 停止小球
    void StopPlayer()
    {
        GameObject player = GameObject.FindGameObjectWithTag("Player");
        if (player != null)
        {
            Rigidbody rb = player.GetComponent<Rigidbody>();
            if (rb != null)
            {
                rb.velocity = Vector3.zero;
                rb.isKinematic = true;
            }

            PlayerController playerController = player.GetComponent<PlayerController>();
            if (playerController != null)
                playerController.enabled = false;
        }
    }

    // 重新开始游戏
    public void RestartGame()
    {
        isGameWin = false;
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }

    // 返回主菜单
    public void ReturnToMainMenu()
    {
        SceneManager.LoadScene(mainMenuSceneName);
    }
}