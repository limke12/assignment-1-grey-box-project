using UnityEngine;
using UnityEngine.UI;

public class ScoreManager : MonoBehaviour
{
    public static ScoreManager Instance;

    [Header("UI��ʾ")]
    public Text scoreText;                  // �÷��ı�
    public Text comboText;                  // �����ı�

    [Header("�÷�����")]
    public int currentScore = 0;
    public int combo = 0;
    public float comboTimeWindow = 2f;      // ����ʱ�䴰��
    private float lastHitTime;

    void Awake()
    {
        // ����ģʽ
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject);
        }
        else
        {
            Destroy(gameObject);
        }
    }

    void Start()
    {
        UpdateUI();
    }

    public void AddScore(int points)
    {
        // �����ж�
        if (Time.time - lastHitTime <= comboTimeWindow)
        {
            combo++;
            // ��������
            int bonus = points * combo;
            currentScore += points + bonus;
            Debug.Log($"���� x{combo}! +{points} + {bonus}����");
        }
        else
        {
            combo = 1;
            currentScore += points;
            Debug.Log($"����Ŀ��! +{points}��");
        }

        lastHitTime = Time.time;
        UpdateUI();

        Debug.Log($"�ܷ�: {currentScore}");
    }

    void UpdateUI()
    {
        if (scoreText != null)
        {
            scoreText.text = $"�÷�: {currentScore}";
        }

        if (comboText != null)
        {
            if (combo > 1)
            {
                comboText.text = $"���� x{combo}";
                comboText.gameObject.SetActive(true);
            }
            else
            {
                comboText.gameObject.SetActive(false);
            }
        }
    }

    public void ResetScore()
    {
        currentScore = 0;
        combo = 0;
        UpdateUI();
    }
}