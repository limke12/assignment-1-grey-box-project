﻿using UnityEngine;

public class PlayerController : MonoBehaviour
{
    [Header("移动设置")]
    public float moveSpeed = 10f;
    public float maxSpeed = 15f;

    [Header("跳跃设置")]
    public float jumpForce = 8f;
    public Transform groundCheck;
    public float groundCheckRadius = 0.2f;
    public LayerMask groundLayer;

    private Rigidbody rb;
    private Vector3 moveDirection;
    private bool isGrounded;

    void Awake()
    {
        // 获取或添加Rigidbody组件
        rb = GetComponent<Rigidbody>();
        if (rb == null)
        {
            rb = gameObject.AddComponent<Rigidbody>();
            rb.mass = 1f;
            rb.drag = 0.5f;
            rb.angularDrag = 0.05f;
            rb.useGravity = true;
        }
        rb.freezeRotation = true;
    }

    void Start()
    {
        // 创建地面检测点
        if (groundCheck == null)
        {
            GameObject checkPoint = new GameObject("GroundCheck");
            checkPoint.transform.parent = transform;
            checkPoint.transform.localPosition = new Vector3(0, -0.5f, 0);
            groundCheck = checkPoint.transform;
        }

        // 设置地面层
        if (groundLayer.value == 0)
        {
            groundLayer = LayerMask.GetMask("Ground");
        }

        Debug.Log("小球控制脚本已启动！使用 WASD 移动，空格跳跃");
    }

    void Update()
    {
        if (rb == null) return;

        // 获取键盘输入
        float moveX = Input.GetAxis("Horizontal");
        float moveZ = Input.GetAxis("Vertical");

        // 计算移动方向
        moveDirection = (transform.right * moveX + transform.forward * moveZ);
        if (moveDirection.magnitude > 0.1f)
        {
            moveDirection.Normalize();
        }

        // 地面检测
        isGrounded = Physics.CheckSphere(groundCheck.position, groundCheckRadius, groundLayer);

        // 跳跃
        if (Input.GetKeyDown(KeyCode.Space) && isGrounded)
        {
            rb.velocity = new Vector3(rb.velocity.x, 0, rb.velocity.z);
            rb.AddForce(Vector3.up * jumpForce, ForceMode.Impulse);
        }

        // 按R键重置位置
        if (Input.GetKeyDown(KeyCode.R))
        {
            transform.position = new Vector3(0, 1, 0);
            rb.velocity = Vector3.zero;
        }
    }

    void FixedUpdate()
    {
        if (rb == null) return;

        // 移动控制
        if (moveDirection.magnitude > 0.01f)
        {
            Vector3 targetVelocity = moveDirection * moveSpeed;
            Vector3 velocityChange = targetVelocity - rb.velocity;
            velocityChange.y = 0;
            rb.AddForce(velocityChange, ForceMode.VelocityChange);
        }

        // 限制最大速度
        Vector3 horizontalVelocity = new Vector3(rb.velocity.x, 0, rb.velocity.z);
        if (horizontalVelocity.magnitude > maxSpeed)
        {
            horizontalVelocity = horizontalVelocity.normalized * maxSpeed;
            rb.velocity = new Vector3(horizontalVelocity.x, rb.velocity.y, horizontalVelocity.z);
        }
    }

    void OnDrawGizmosSelected()
    {
        if (groundCheck != null)
        {
            Gizmos.color = Color.red;
            Gizmos.DrawWireSphere(groundCheck.position, groundCheckRadius);
        }
    }
}